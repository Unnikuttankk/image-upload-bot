# Session Name
SESSION_NAME = "MT-Telegr-Ph"
